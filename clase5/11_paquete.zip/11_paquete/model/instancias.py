from .persona import Persona

persona_1 = Persona("Juan", "Pérez", 25)
persona_2 = Persona("Pedro", "Rodriguez", 40)
persona_3 = Persona("Maria", "Gonzalez", 35)
